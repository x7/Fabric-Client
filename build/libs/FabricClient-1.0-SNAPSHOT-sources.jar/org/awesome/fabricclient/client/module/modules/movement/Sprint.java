package org.awesome.fabricclient.client.module.modules.movement;

import org.awesome.fabricclient.client.module.Module;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Automatically sprints for you", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        System.out.println("Enabled");
    }

    @Override
    public void onDisable() {
        System.out.println("Disabled");
    }
}
