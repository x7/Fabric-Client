package org.awesome.fabricclient.client.module.modules.movement;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.Connection;
import net.minecraft.world.entity.monster.breeze.Slide;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.awesome.fabricclient.client.module.Module;
import org.awesome.fabricclient.client.module.settings.ModeSelectSetting;
import org.awesome.fabricclient.client.module.settings.SliderSetting;
import org.awesome.fabricclient.client.utility.MinecraftUtility;
import org.awesome.fabricclient.client.utility.PlayerUtility;
import org.awesome.fabricclient.client.utility.Utility;

public class Sprint extends Module {
    public final ModeSelectSetting mode = addSetting(new ModeSelectSetting("Mode", "Sprint Mode", "Legit", "Legit", "Blatant"));
    public final SliderSetting backwardsSlider = addSetting(new SliderSetting("Backwards Multiplier", "Increases the speed when walking backwards", 1.0, 1.0, 5.0));
    public final SliderSetting sidewardsSlider = addSetting(new SliderSetting("Sidewards Multiplier", "Increases the speed when walking sidewards", 1.0, 1.0, 5.0));

    public Sprint() {
        super("Sprint", "Automatically sprints for you", Category.MOVEMENT);
        backwardsSlider.visibleWhen(() -> mode.getValue().equalsIgnoreCase("blatant"));
        sidewardsSlider.visibleWhen(() -> mode.getValue().equalsIgnoreCase("blatant"));
    }

    @Override
    public void onEnable() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if(!isEnabled()) {
                return;
            }

            Player player = PlayerUtility.getPlayer();
//
//            if(player.isSprinting()) {
//                return;
//            }

            boolean isWDown = Utility.isKeyDown(InputConstants.getKey("key.keyboard.w"));
            boolean isSDown = Utility.isKeyDown(InputConstants.getKey("key.keyboard.s"));
            boolean isADown = Utility.isKeyDown(InputConstants.getKey("key.keyboard.a"));
            boolean isDDown = Utility.isKeyDown(InputConstants.getKey("key.keyboard.d"));


            System.out.println(player.getDeltaMovement());

            if(isWDown) {
                player.setSprinting(true);
                return;
            }

            if(mode.getValue().equalsIgnoreCase("legit")) {
                return;
            }

            // Blatant mode
            double walkingFowardSpeed = 0.154;
            Vec3 playerMovement = player.getDeltaMovement();
            ClientPacketListener c = MinecraftUtility.getPacketListener();
            if(c == null) {
                System.out.println("packet null");
                return;
            }


            System.out.println(c.hasClientLoaded());
            System.out.println(MinecraftUtility.getConnection().getRemoteAddress());
            if(isSDown) {
                Vec3 newPlayerMovement = new Vec3(walkingFowardSpeed, playerMovement.y, playerMovement.z);
                player.setDeltaMovement(newPlayerMovement);
                return;
            }
        });
    }
}
