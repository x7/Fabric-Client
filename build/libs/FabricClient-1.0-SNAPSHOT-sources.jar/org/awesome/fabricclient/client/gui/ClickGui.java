package org.awesome.fabricclient.client.gui;

import net.minecraft.client.Minecraft;
import org.joml.Matrix3x2fStack;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.awesome.fabricclient.client.module.Module;
import org.awesome.fabricclient.client.module.ModuleManager;
import org.awesome.fabricclient.client.module.settings.*;

import java.util.List;

public class ClickGui extends Screen {

    // ── Layout ────────────────────────────────────────────────────────────────
    // These are TRUE framebuffer pixels, rendered after the GUI scale matrix is
    // cancelled.  They look the same at every GUI scale setting.
    private static final int GUI_W          = 960;
    private static final int GUI_H          = 520;
    private static final int GUI_SETTINGS_W = 280;

    private static final int SIDEBAR_W   = 110;  // left category sidebar
    private static final int SIDEBAR_PAD = 10;   // padding inside sidebar items
    private static final int CAT_H       = 34;   // height of each category row

    private static final int CONTENT_PAD = 14;
    private static final int CARD_COLS   = 2;
    private static final int CARD_GAP    = 8;
    private static final int CARD_H      = 56;

    // ── Scale helpers ─────────────────────────────────────────────────────────
    /** Current GUI scale factor (set each frame). */
    private double guiScale = 1.0;

    /** Raw framebuffer width/height (scaled-pixels × guiScale). */
    private int fbW() { return (int)(this.width  * guiScale); }
    private int fbH() { return (int)(this.height * guiScale); }

    private static final int   SCROLL_SPEED   = 10;

    // ── Colours ───────────────────────────────────────────────────────────────
    private static final int C_BG           = 0xF2111620;  // deeper navy base
    private static final int C_BG_DARK      = 0xF00C1018;  // content area slightly darker
    private static final int C_TAB_BAR      = 0xF0141A26;  // distinct tab strip
    private static final int C_TAB_ACTIVE   = 0xF0192134;
    private static final int C_TAB_HOVER    = 0xBB18202E;
    private static final int C_TAB_TEXT     = 0xFFE8F0FF;  // brighter active tab text
    private static final int C_TAB_TEXT_DIM = 0xFF48587A;
    private static final int C_BORDER       = 0xFF1A2640;  // subtle outer border
    private static final int C_CARD         = 0xCC131C2E;
    private static final int C_CARD_HOVER   = 0xCC1C2840;
    private static final int C_CARD_BORDER  = 0xFF1C2A42;
    private static final int C_CARD_SEL     = 0xCC1E2C46;
    private static final int C_CARD_SEL_BRD = 0xFF2E4E78;  // blue-ish selected border
    private static final int C_TEXT         = 0xFFDDE8FA;
    private static final int C_TEXT_DIM     = 0xFF526070;
    private static final int C_TEXT_DESC    = 0xFF788898;
    private static final int C_ACCENT       = 0xFFE8701A;  // warm orange
    private static final int C_ACCENT_BRD   = 0xFFFF8C3A;
    private static final int C_PILL_ON      = 0xFFE8701A;
    private static final int C_PILL_OFF     = 0xFF222E44;
    private static final int C_PILL_KNOB    = 0xFFFFFFFF;
    private static final int C_SET_BG       = 0xF00E1422;
    private static final int C_SET_BORDER   = 0xFF1E3050;
    private static final int C_SLIDER_BG    = 0xFF162030;
    private static final int C_SLIDER_FILL  = 0xFFE8701A;
    private static final int C_SLIDER_KNOB  = 0xFFFFFFFF;
    private static final int C_OVERLAY      = 0x88040810;  // lighter scrim
    private static final int C_SCROLLBAR    = 0xFF18243A;
    private static final int C_SCROLLBAR_TH = 0xFF3A5272;

    // ── State ─────────────────────────────────────────────────────────────────
    private Module.Category activeTab      = Module.Category.COMBAT;
    private Module          settingsModule = null;

    // Scroll offsets (pixels scrolled down)
    private int             moduleScroll   = 0;
    private int             settingsScroll = 0;

    private boolean        draggingSlider = false;
    private SliderSetting  activeSlider   = null;
    private int            sliderBarX, sliderBarW;
    private InputSetting   activeInput    = null;

    // ── Constructor ───────────────────────────────────────────────────────────
    public ClickGui() {
        super(Component.literal("ClickGUI"));
    }

    // ── Rendering ─────────────────────────────────────────────────────────────
    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float delta) {
        super.extractRenderState(g, mx, my, delta);

        // Snap the current GUI scale so mouse helpers can convert correctly.
        guiScale = Minecraft.getInstance().getWindow().getGuiScale();

        // Cancel the GUI scale matrix — everything below is in raw framebuffer pixels.
        Matrix3x2fStack ps = g.pose();
        ps.pushMatrix();
        ps.scale((float)(1.0 / guiScale), (float)(1.0 / guiScale));

        // Convert scaled mouse → raw framebuffer mouse for hit-testing.
        int rmx = (int)(mx * guiScale);
        int rmy = (int)(my * guiScale);

        g.fill(0, 0, fbW(), fbH(), C_OVERLAY);

        int gx = guiX(), gy = guiY();
        int gw = GUI_W,  gh = GUI_H;

        // Shadow
        g.fill(gx + 4, gy + 4, gx + gw + 4, gy + gh + 4, 0x55000000);

        // Main panel background
        g.fill(gx, gy, gx + gw, gy + gh, C_BG);
        g.outline(gx, gy, gw, gh, C_BORDER);

        // Left sidebar
        g.fill(gx, gy, gx + SIDEBAR_W, gy + gh, C_TAB_BAR);
        g.fill(gx + SIDEBAR_W - 1, gy, gx + SIDEBAR_W, gy + gh, C_BORDER);

        renderSidebar(g, gx, gy, gh, rmx, rmy);

        // Content area (right of sidebar)
        int contentX = gx + SIDEBAR_W;
        int contentW = gw - SIDEBAR_W;
        renderContent(g, contentX, gy, contentW, gh, rmx, rmy);

        if (settingsModule != null) {
            renderSettingsPanel(g, gx + gw, gy, gh, rmx, rmy);
        }

        ps.popMatrix();
    }

    // ── Left category sidebar ─────────────────────────────────────────────────
    private void renderSidebar(GuiGraphicsExtractor g, int gx, int gy, int gh, int mx, int my) {
        // Client name header at top of sidebar
        g.fill(gx, gy, gx + SIDEBAR_W, gy + 28, C_BG_DARK);
        g.fill(gx, gy + 28, gx + SIDEBAR_W, gy + 29, C_ACCENT);
        g.text(this.font, "§6Awesome", gx + SIDEBAR_PAD, gy + 9, C_TEXT, true);

        int catY = gy + 36;
        for (Module.Category cat : Module.Category.values()) {
            boolean active  = cat == activeTab;
            boolean hovered = !active && isIn(mx, my, gx, catY, SIDEBAR_W, CAT_H);

            if (active) {
                g.fill(gx, catY, gx + SIDEBAR_W, catY + CAT_H, C_TAB_ACTIVE);
                // Left accent bar for active
                g.fill(gx, catY, gx + 2, catY + CAT_H, C_ACCENT);
            } else if (hovered) {
                g.fill(gx, catY, gx + SIDEBAR_W, catY + CAT_H, C_TAB_HOVER);
            }

            int textCol = active ? C_TAB_TEXT : (hovered ? C_TAB_TEXT : C_TAB_TEXT_DIM);
            g.text(this.font, cat.displayName, gx + SIDEBAR_PAD + 6, catY + (CAT_H - 8) / 2, textCol, active);

            catY += CAT_H;
        }
    }

    // ── Module grid with scroll ───────────────────────────────────────────────
    private void renderContent(GuiGraphicsExtractor g, int cx, int cy, int cw, int ch, int mx, int my) {
        List<Module> mods = ModuleManager.getInstance().getModulesByCategory(activeTab);
        g.fill(cx, cy, cx + cw, cy + ch, C_BG_DARK);

        int cardW  = (cw - CONTENT_PAD * 2 - CARD_GAP * (CARD_COLS - 1)) / CARD_COLS;
        int rows   = (mods.size() + CARD_COLS - 1) / CARD_COLS;
        int totalH = rows * (CARD_H + CARD_GAP) - CARD_GAP + CONTENT_PAD * 2;

        int maxScroll = Math.max(0, totalH - ch);
        moduleScroll  = Math.max(0, Math.min(moduleScroll, maxScroll));

        for (int i = 0; i < mods.size(); i++) {
            Module mod  = mods.get(i);
            int cardX   = cx + CONTENT_PAD + (i % CARD_COLS) * (cardW + CARD_GAP);
            int cardY   = cy + CONTENT_PAD + (i / CARD_COLS) * (CARD_H + CARD_GAP) - moduleScroll;
            if (cardY + CARD_H < cy || cardY > cy + ch) continue;
            boolean hov = isIn(mx, my, cardX, cardY, cardW, CARD_H);
            drawCard(g, mod, cardX, cardY, cardW, hov);
        }

        if (mods.isEmpty()) {
            String msg = "No modules in this category.";
            g.text(this.font, msg, cx + cw / 2 - font.width(msg) / 2, cy + ch / 2 - 4, C_TEXT_DIM, false);
        }

        if (maxScroll > 0) drawScrollbar(g, cx + cw - 5, cy + 2, 4, ch - 4, moduleScroll, totalH);
    }

    private void drawCard(GuiGraphicsExtractor g, Module mod, int x, int y, int w, boolean hov) {
        boolean selected = mod == settingsModule;
        int bg  = selected ? C_CARD_SEL     : (hov ? C_CARD_HOVER : C_CARD);
        int brd = selected ? C_CARD_SEL_BRD : C_CARD_BORDER;

        g.fill(x, y, x + w, y + CARD_H, bg);
        g.outline(x, y, w, CARD_H, brd);

        // Left accent bar — thin inset stripe
        if (mod.isEnabled()) g.fill(x, y + 3, x + 2, y + CARD_H - 3, C_ACCENT);

        int nameColor = mod.isEnabled() ? C_TEXT : C_TEXT_DIM;
        g.text(this.font, mod.getName(), x + 12, y + 9, nameColor, mod.isEnabled());

        // Keybind tag
        String bind = "NONE";
        int tagX = x + 12 + font.width(mod.getName()) + 6;
        g.fill(tagX - 2, y + 7, tagX + font.width(bind) + 3, y + 19, 0x330D1828);
        g.text(this.font, bind, tagX, y + 9, 0xFF334560, false);

        // Description
        String desc = mod.getDescription();
        if (desc != null && !desc.isEmpty()) {
            g.text(this.font, trimW(desc, w - 60), x + 12, y + 28, C_TEXT_DESC, false);
        }

        // Toggle pill
        drawPill(g, mod.isEnabled(), x + w - 46, y + CARD_H / 2 - 8);
    }

    private void drawPill(GuiGraphicsExtractor g, boolean on, int x, int y) {
        // Track: 36×16
        int tw = 36, th = 16;
        int trackCol  = on ? C_PILL_ON  : C_PILL_OFF;
        int borderCol = on ? C_ACCENT_BRD : 0xFF253348;

        // Track fill
        g.fill(x, y, x + tw, y + th, trackCol);
        // Track border
        g.outline(x, y, tw, th, borderCol);
        // Inner top shadow for depth
        g.fill(x + 1, y + 1, x + tw - 1, y + 3, on ? 0x22000000 : 0x18000000);

        // Knob
        int kSize = th - 4;  // 12px
        int kx = on ? x + tw - kSize - 2 : x + 2;
        int ky = y + 2;
        // Knob shadow
        g.fill(kx + 1, ky + 1, kx + kSize + 1, ky + kSize + 1, 0x44000000);
        // Knob face
        g.fill(kx, ky, kx + kSize, ky + kSize, C_PILL_KNOB);
        // Knob highlight top-left
        g.fill(kx, ky, kx + kSize, ky + 2, 0x33FFFFFF);
    }

    // ── Settings panel with scroll ────────────────────────────────────────────
    private void renderSettingsPanel(GuiGraphicsExtractor g, int px, int py, int gh, int mx, int my) {
        int sw = settingsW();

        g.fill(px + 3, py + 3, px + sw + 3, py + gh + 3, 0x44000000);
        g.fill(px, py, px + sw, py + gh, C_SET_BG);
        g.outline(px, py, sw, gh, C_SET_BORDER);

        // Header (28px tall to match sidebar header)
        g.fill(px, py, px + sw, py + 28, C_TAB_BAR);
        g.fill(px, py + 27, px + sw, py + 28, C_BORDER);
        g.fill(px, py + 26, px + sw, py + 28, C_ACCENT);
        g.text(this.font, settingsModule.getName(), px + 8, py + 9, C_TEXT, true);
        g.text(this.font, "x", px + sw - 14, py + 9, C_TEXT_DIM, false);

        int contentY = py + 28;
        int contentH = gh - 28;

        // Calculate total settings height
        List<Setting<?>> settings = settingsModule.getSettings();
        int totalSH = 8;
        for (Setting<?> s : settings) totalSH += settingH(s) + 4;

        int maxScroll = Math.max(0, totalSH - contentH);
        settingsScroll = Math.max(0, Math.min(settingsScroll, maxScroll));

        int sy = contentY + 8 - settingsScroll;
        for (Setting<?> s : settings) {
            int sh = settingH(s);
            if (sy + sh >= contentY && sy <= contentY + contentH) {
                boolean hov = isIn(mx, my, px + 6, sy, sw - 12, sh);
                drawSetting(g, s, px + 6, sy, sw - 12, hov);
            }
            sy += sh + 4;
        }

        if (settings.isEmpty()) {
            g.text(this.font, "No settings.", px + 8, contentY + 12, C_TEXT_DIM, false);
        }

        if (maxScroll > 0) drawScrollbar(g, px + sw - 5, contentY + 2, 4, contentH - 4, settingsScroll, totalSH);
    }

    private int settingH(Setting<?> s) {
        return (s instanceof SliderSetting) ? 42 : 30;
    }

    private void drawSetting(GuiGraphicsExtractor g, Setting<?> s, int x, int y, int w, boolean hov) {
        int sh = settingH(s);
        if (hov) g.fill(x - 4, y, x + w + 4, y + sh, 0x18FFFFFF);
        g.fill(x, y + sh, x + w, y + sh + 1, 0x22FFFFFF);

        if (s instanceof BooleanSetting b) {
            g.text(this.font, b.getName(), x + 4, y + 8, C_TEXT_DIM, false);
            drawPill(g, b.getValue(), x + w - 40, y + sh / 2 - 8);

        } else if (s instanceof SliderSetting sl) {
            double pct  = (sl.getValue() - sl.getMin()) / (sl.getMax() - sl.getMin());
            int bx = x + 4, bw = w - 8, by = y + 28;
            int knob = bx + (int)(bw * pct);
            String val = String.format("%.1f", sl.getValue());
            g.text(this.font, sl.getName(), x + 4, y + 8, C_TEXT_DIM, false);
            g.text(this.font, val, x + w - font.width(val) - 4, y + 8, C_TEXT, true);
            g.fill(bx, by, bx + bw, by + 4, C_SLIDER_BG);
            g.fill(bx, by, knob,    by + 4, C_SLIDER_FILL);
            g.fill(knob - 4, by - 3, knob + 4, by + 7, C_SLIDER_KNOB);

        } else if (s instanceof ModeSelectSetting m) {
            g.text(this.font, m.getName(), x + 4, y + 8, C_TEXT_DIM, false);
            String val = m.getValue();
            g.text(this.font, val, x + w - font.width(val) - 4, y + 8, C_TEXT, true);

        } else if (s instanceof InputSetting inp) {
            boolean active = inp == activeInput;
            String val = trimW(active ? inp.getValue() + "|" : inp.getValue(), w / 2);
            g.text(this.font, inp.getName(), x + 4, y + 8, C_TEXT_DIM, false);
            g.text(this.font, val, x + w - font.width(val) - 4, y + 8,
                    active ? C_TEXT : C_TEXT_DIM, active);
        }
    }

    // ── Scrollbar ─────────────────────────────────────────────────────────────
    private void drawScrollbar(GuiGraphicsExtractor g, int x, int y, int w, int h, int scroll, int total) {
        g.fill(x, y, x + w, y + h, C_SCROLLBAR);
        int thumbH = Math.max(16, h * h / total);
        int thumbY = y + (int)((h - thumbH) * (double)scroll / Math.max(1, total - h));
        g.fill(x, thumbY, x + w, thumbY + thumbH, C_SCROLLBAR_TH);
    }

    // ── Input ─────────────────────────────────────────────────────────────────
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        // Convert scaled-pixel mouse → raw framebuffer coords to match our drawing space.
        double mx = event.x() * guiScale;
        double my = event.y() * guiScale;
        int btn = event.button();
        int gx = guiX(), gy = guiY();
        int gw = guiW(), gh = guiH();

        // Sidebar category hit-testing
        int catY = gy + 36;
        for (Module.Category cat : Module.Category.values()) {
            if (isIn(mx, my, gx, catY, SIDEBAR_W, CAT_H)) {
                activeTab = cat;
                settingsModule = null;
                moduleScroll = 0;
                return true;
            }
            catY += CAT_H;
        }

        // Settings panel
        if (settingsModule != null) {
            int px = gx + gw;
            int sw = settingsW();
            // Close button
            if (isIn(mx, my, px + sw - 16, gy + 7, 12, 12)) {
                settingsModule = null;
                settingsScroll = 0;
                return true;
            }
            int contentY = gy + 28;
            int sy = contentY + 8 - settingsScroll;
            for (Setting<?> s : settingsModule.getSettings()) {
                int sh = settingH(s);
                if (isIn(mx, my, px + 6, sy, sw - 12, sh)) {
                    handleSettingClick(s, px + 6, sw - 12, mx);
                    return true;
                }
                sy += sh + 4;
            }
        }

        // Module cards
        List<Module> mods  = ModuleManager.getInstance().getModulesByCategory(activeTab);
        int contentX = gx + SIDEBAR_W;
        int contentW = gw - SIDEBAR_W;
        int cardW    = (contentW - CONTENT_PAD * 2 - CARD_GAP * (CARD_COLS - 1)) / CARD_COLS;

        for (int i = 0; i < mods.size(); i++) {
            Module mod   = mods.get(i);
            int    cardX = contentX + CONTENT_PAD + (i % CARD_COLS) * (cardW + CARD_GAP);
            int    cardY = gy + CONTENT_PAD + (i / CARD_COLS) * (CARD_H + CARD_GAP) - moduleScroll;
            if (isIn(mx, my, cardX, cardY, cardW, CARD_H)) {
                if (btn == 0) mod.toggle();
                else if (btn == 1) {
                    settingsModule = (settingsModule == mod) ? null : mod;
                    settingsScroll = 0;
                }
                return true;
            }
        }

        activeInput = null;
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        // Convert to raw framebuffer coords.
        mx *= guiScale;
        my *= guiScale;
        int gx = guiX(), gy = guiY();
        int gw = guiW(), gh = guiH();
        int delta = scrollY > 0 ? -SCROLL_SPEED : SCROLL_SPEED;

        // Scroll settings panel
        if (settingsModule != null) {
            int px = gx + gw;
            int sw = settingsW();
            if (isIn(mx, my, px, gy, sw, gh)) {
                settingsScroll = Math.max(0, settingsScroll + delta);
                return true;
            }
        }

        // Scroll module grid (content area is right of sidebar)
        if (isIn(mx, my, gx + SIDEBAR_W, gy, gw - SIDEBAR_W, gh)) {
            moduleScroll = Math.max(0, moduleScroll + delta);
            return true;
        }

        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    private void handleSettingClick(Setting<?> s, int barX, int barW, double mx) {
        if (s instanceof BooleanSetting b)         b.toggle();
        else if (s instanceof ModeSelectSetting m) m.cycle();
        else if (s instanceof SliderSetting sl) {
            draggingSlider = true;
            activeSlider   = sl;
            sliderBarX     = barX + 2;
            sliderBarW     = barW - 4;
            updateSlider(mx);
        } else if (s instanceof InputSetting inp)
            activeInput = (activeInput == inp) ? null : inp;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (draggingSlider && activeSlider != null) { updateSlider(event.x() * guiScale); return true; }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        draggingSlider = false;
        activeSlider   = null;
        return super.mouseReleased(event);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (activeInput != null) {
            if (event.key() == 259 && !activeInput.getValue().isEmpty()) {
                activeInput.setValue(activeInput.getValue().substring(0, activeInput.getValue().length() - 1));
                return true;
            }
            if (event.isEscape()) { activeInput = null; return true; }
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (activeInput != null) {
            if (event.isAllowedChatCharacter())
                activeInput.setValue(activeInput.getValue() + event.codepointAsString());
            return true;
        }
        return super.charTyped(event);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private void updateSlider(double mx) {
        double pct = Math.max(0, Math.min(1, (mx - sliderBarX) / sliderBarW));
        activeSlider.setValue(activeSlider.getMin() + pct * (activeSlider.getMax() - activeSlider.getMin()));
    }

    private int guiW() { return GUI_W; }
    private int guiH() { return GUI_H; }

    private int settingsW() { return GUI_SETTINGS_W; }

    private int guiX() {
        int total = settingsModule != null ? GUI_W + GUI_SETTINGS_W : GUI_W;
        return (fbW() - total) / 2;
    }

    private int guiY() {
        return (fbH() - GUI_H) / 2;
    }

    private boolean isIn(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private String trimW(String text, int maxPx) {
        if (font.width(text) <= maxPx) return text;
        while (!text.isEmpty() && font.width(text + "…") > maxPx)
            text = text.substring(0, text.length() - 1);
        return text + "…";
    }

    @Override
    public boolean isPauseScreen() { return false; }
}